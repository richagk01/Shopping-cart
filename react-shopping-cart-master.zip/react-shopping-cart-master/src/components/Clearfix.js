import React from 'react';

const Clearfix = () => (
  <div className="clearfix"></div>
);

export default Clearfix;